import cv2
import glob
import pandas as pd
import xml.etree.ElementTree as ET


def read_img(path):
    images = [cv2.imread(file) for file in glob.glob(path)]
    print("Total Images : "+str(len(images)))
    return images



def draw_annotation(image_path,label_path):
    images = read_img(image_path)
    i=0
    for file in glob.glob(label_path):
        image = images[i]
        root_node = ET.parse(file)
        data = root_node.findall('object')
        for l in data:
            name = l.find('name').text
            bndbox = l.findall('bndbox')
            #print(bndbox)
            for b in bndbox:
                x1,y1,x2,y2 = int(float(b.find('xmin').text)), int(float(b.find('ymin').text)), int(float(b.find('xmax').text)), int(float(b.find('ymax').text))
                cv2.rectangle(image,(x1,y1),(x2,y2),(255,0,0),1)
                cv2.putText(image,name,(x1, y1-10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,0,255), 1)
                #print(x1,y1,x2,y2)
        cv2.imshow("abc",image)
        cv2.waitKey(0)
        cv2.imwrite('result/img'+str(i)+'.jpg',image)
        i=i+1



#draw_annotation("intern-assignment/*.png","intern-assignment/*.xml")
